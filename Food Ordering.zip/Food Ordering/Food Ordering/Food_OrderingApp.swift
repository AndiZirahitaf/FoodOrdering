//
//  Food_OrderingApp.swift
//  Food Ordering
//
//  Created by AndyZett on 01/03/21.
//

import SwiftUI
import Firebase
import FirebaseCore

@main
struct Food_OrderingApp: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

class AppDelegate: NSObject, UIApplicationDelegate {
    
    func application(_application: UIApplication,
        didFinishLaunchingWithOptions launchOptions:
            [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        
        FirebaseApp.configure()
        return true
    }
}
